package com.example.mad;

import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button speak = findViewById(R.id.speak);
        Button qr = findViewById(R.id.qr);
        TextView welcomeText = findViewById(R.id.welcomeText); // Changed to TextView

        qr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                String content = welcomeText.getText().toString(); // Changed to welcomeText
                i.putExtra("key1", content);
                startActivity(i);
            }
        });

        speak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity3.class);
                String content = welcomeText.getText().toString(); // Changed to welcomeText
                i.putExtra("key1", content);
                startActivity(i);
            }
        });
    }
}
